#include <stdio.h>
#define inputfile "input.txt"
#define outputfile "output.txt"

void read_file( int * , int *);
void init_arrays( int * ,int * , int );
void find_succesives(int * , int * , int * , int , int * );
void print_file(int * , int * , int * , int );

int main(){
    int total_number = 0 , ind = 0 ; int inp_arr[100];
           read_file(inp_arr,&total_number);
   int sec_gram[total_number] , count[total_number];
           init_arrays(sec_gram , count  , total_number);
           find_succesives(inp_arr,sec_gram,count,total_number , &ind);
           print_file(inp_arr,sec_gram,count,ind);
   return 0;
}

void find_succesives( int *first , int * second , int * count ,int total_number , int *ind){

       second[0] = first[1];
       int flag =1;
    
       for(int i = 1 ; i <  total_number-1  ; i++){
       int flag =0;
         for(int j = 0 ; j<=*ind;  j++){
          if(first[j] == first[i] && second[j] == first[i+1]) {
            count[j]++;
            flag = 1;
            j=(*ind)+1;
          }
         }
        if(flag == 0 ){
          (*ind)++;
          first[(*ind)] = first[i];
          second[(*ind)] = first[i+1];
        }     
       }
      }

    void init_arrays( int * second , int * count , int total_number){
        for(int i = 0 ; i< total_number ; i++){ 
          second[i] =0 ; count[i] = 1;
        }
     }
    
void read_file( int *container , int* total){
   FILE *fp = fopen(inputfile,"r");
    int num = 0 ;
    if( fp == NULL){
        printf("File could  not opened");
        return;
    }
    else { 
            while(fscanf(fp ,"%d",&num) == 1){
                container[*total] = num;
              (*total)++;
       }
    }
  fclose(fp);
}

void print_file(int *first , int * second , int * count , int ind){
 FILE *fpo = fopen(outputfile,"w");
     for(int i = 0 ; i <=ind ; i++){
      printf("%d %d : %d\n",first[i],second[i],count[i]);
      fprintf(fpo,"%d %d : %d\n",first[i],second[i],count[i]);
    }
        fclose(fpo);
}